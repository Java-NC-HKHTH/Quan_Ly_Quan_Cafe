
package DAO;

import Model.HoaDon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

public class HoaDonDAO {
    public List<HoaDon> getAllHoaDon(){
        List<HoaDon> list = new ArrayList<>();
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "SELECT HD.maHoaDon, thoiGian, maKhach, tinhTrangDon, hoVaTen, SUM(soLuong*donGia*(100-chietkhau+vat)/100) As N'thanhTien'\n" +
                    "FROM tblHoaDon AS HD, tblChiTietDonHang AS CTDH, tblNhanVien AS NV\n" +
                    "WHERE HD.maHoaDon = CTDH.maHoaDon AND HD.maNhanVien = NV.maNhanVien\n" +
                    "GROUP BY HD.maHoaDon, thoiGian, maKhach, tinhTrangDon, hoVaTen\n" +
                    "ORDER BY HD.maHoaDon DESC";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                HoaDon hd = new HoaDon();
                hd.setMaHoaDon(rs.getInt("maHoaDon"));
                hd.setThoiGian(rs.getTimestamp("thoiGian"));
                hd.setMaKhach(rs.getInt("maKhach"));
                hd.setTinhTrangDon(rs.getString("tinhTrangDon"));
                hd.setTenNhanVien(rs.getString("hoVaTen"));
                hd.setThanhTien(rs.getLong("thanhTien"));
                list.add(hd);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
    public List<HoaDon> getDSHDTrongNgay(){
        List<HoaDon> list = new ArrayList<>();
        Connection con = JDBCConnection.getJDBCConnection();
        String sql =  "SELECT tblHoaDon.maHoaDon, thoiGian, SUM(soLuong*donGia*(100-chietkhau+vat)/100) As 'thanhTien', tinhTrangDon, maKhach, hoVaTen\n" +
                    "FROM tblChiTietDonHang, tblHoaDon, tblNhanVien\n" +
                    "WHERE tblChiTietDonHang.maHoaDon = tblHoaDon.maHoaDon AND tblHoaDon.maNhanVien = tblNhanVien.maNhanVien AND CONVERT(VARCHAR, thoiGian, 103) = CONVERT(VARCHAR, getdate(), 103)\n" +
                    "GROUP BY tblHoaDon.maHoaDon, thoiGian, tinhTrangDon, maKhach, hoVaTen\n" +
                    "ORDER BY tblHoaDon.maHoaDon DESC";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                HoaDon hd = new HoaDon();
                hd.setMaHoaDon(rs.getInt("maHoaDon"));
                hd.setThoiGian(rs.getTimestamp("thoiGian"));
                hd.setThanhTien(rs.getLong("thanhTien"));
                hd.setMaKhach(rs.getInt("maKhach"));
                hd.setTinhTrangDon(rs.getString("tinhTrangDon"));
                hd.setTenNhanVien(rs.getString("hoVaTen"));
                list.add(hd);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
    public List<HoaDon> getDSHDTrongNgayTT(String tt){
        List<HoaDon> list = new ArrayList<>();
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "SELECT tblHoaDon.maHoaDon, thoiGian, SUM(soLuong*donGia*(100-chietkhau+vat)/100) As 'thanhTien', tinhTrangDon, maKhach, hoVaTen\n" +
                    "FROM tblChiTietDonHang, tblHoaDon, tblNhanVien\n" +
                    "WHERE tblChiTietDonHang.maHoaDon = tblHoaDon.maHoaDon AND tblHoaDon.maNhanVien = tblNhanVien.maNhanVien AND CONVERT(VARCHAR, thoiGian, 103) = CONVERT(VARCHAR, getdate(), 103) AND tinhTrangDon = ?\n" +
                    "GROUP BY tblHoaDon.maHoaDon, thoiGian, tinhTrangDon, maKhach, hoVaTen\n" +
                    "ORDER BY tblHoaDon.maHoaDon DESC";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, tt);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                HoaDon hd = new HoaDon();
                hd.setMaHoaDon(rs.getInt("maHoaDon"));
                hd.setThoiGian(rs.getTimestamp("thoiGian"));
                hd.setThanhTien(rs.getLong("thanhTien"));
                hd.setMaKhach(rs.getInt("maKhach"));
                hd.setTinhTrangDon(rs.getString("tinhTrangDon"));
                hd.setTenNhanVien(rs.getString("hoVaTen"));
                list.add(hd);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
    public HoaDon getChiTiet1HD(int mahd){
        HoaDon hd = new HoaDon();
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "SELECT maKhach, SUM(soLuong*donGia) As 'tongCong', chietKhau, vat, tienKhachTra"+
                    " FROM tblChiTietDonHang, tblHoaDon"+
                    " WHERE tblChiTietDonHang.maHoaDon = tblHoaDon.maHoaDon AND tblHoaDon.maHoaDon = ?"+
                    " GROUP BY maKhach, chietKhau, vat, tienKhachTra";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, mahd);
            ResultSet rs = ps.executeQuery();
            rs.next();
            hd.setMaKhach(rs.getInt("maKhach"));
            hd.setTongCong(rs.getLong("tongCong"));
            hd.setChietKhau(rs.getInt("chietKhau"));
            hd.setVat(rs.getInt("vat"));
            hd.setTienKhachTra(rs.getLong("tienKhachTra"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hd;
    }
    public int kt = 0;
    public void addHoaDon(HoaDon hd){
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "INSERT INTO tblHoaDon(chietKhau, vat, tienKhachTra, maKhach, maNhanVien)"
                    + " VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, hd.getChietKhau());
            ps.setInt(2, hd.getVat());
            ps.setLong(3, hd.getTienKhachTra());
            ps.setInt(4, hd.getMaKhach());
            ps.setInt(5, hd.getMaNhanVien());
            kt = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(kt);
    }
    
   public int getMaHDMoiThem(){
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "SELECT MAX(maHoaDon) AS 'maHoaDon' FROM tblHoaDon";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            rs.next();
            int mhd = rs.getInt("maHoaDon");
            return mhd;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
   
   //Lấy doanh thu theo ngày
   public long getDTTheoNgay(Date d){
        long dt = 0;
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "SELECT SUM(soLuong*donGia*(100-chietkhau+vat)/100) As 'doanhThu'"+
                    " FROM tblChiTietDonHang, tblHoaDon"+
                    " WHERE tblChiTietDonHang.maHoaDon = tblHoaDon.maHoaDon AND CONVERT(VARCHAR, thoiGian, 103) = CONVERT(VARCHAR, ?, 103)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, d);
            ResultSet rs = ps.executeQuery();
            rs.next();
            dt = rs.getLong("doanhThu");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dt;
    }
   
   public List<HoaDon> getDSHDKhoangNgay(Date bd, Date kt){
        List<HoaDon> list = new ArrayList<>();
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "SELECT H.maHoaDon, thoiGian, SUM(soLuong*donGia*(100-chietkhau+vat)/100) As N'thanhTien', tinhTrangDon, maKhach, hoVaTen\n" +
                    "FROM tblChiTietDonHang AS C, tblHoaDon AS H, tblNhanVien AS NV\n" +
                    "WHERE C.maHoaDon = H.maHoaDon AND H.maNhanVien = NV.maNhanVien AND CONVERT(VARCHAR, thoiGian, 103) BETWEEN CONVERT(VARCHAR, ?, 103) AND CONVERT(VARCHAR, ?, 103)\n" +
                    "GROUP BY H.maHoaDon, thoiGian, tinhTrangDon, maKhach, hoVaTen\n" +
                    "ORDER BY H.maHoaDon DESC";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, bd);
            ps.setDate(2, kt);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                HoaDon hd = new HoaDon();
                hd.setMaHoaDon(rs.getInt("maHoaDon"));
                hd.setThoiGian(rs.getTimestamp("thoiGian"));
                hd.setThanhTien(rs.getLong("thanhTien"));
                hd.setMaKhach(rs.getInt("maKhach"));
                hd.setTinhTrangDon(rs.getString("tinhTrangDon"));
                hd.setTenNhanVien(rs.getString("hoVaTen"));
                list.add(hd);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
    public List<HoaDon> getHDTrangThai(String trangThai){
        List<HoaDon> list = new ArrayList<>();
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "SELECT HD.maHoaDon, thoiGian, maKhach, tinhTrangDon, hoVaTen, SUM(soLuong*donGia*(100-chietkhau+vat)/100) As N'thanhTien'\n" +
                    "FROM tblHoaDon AS HD, tblChiTietDonHang AS CTDH, tblNhanVien AS NV\n" +
                    "WHERE HD.maHoaDon = CTDH.maHoaDon AND HD.maNhanVien = NV.maNhanVien AND tinhTrangDon = ?\n" +
                    "GROUP BY HD.maHoaDon, thoiGian, maKhach, tinhTrangDon, hoVaTen\n" +
                    "ORDER BY HD.maHoaDon DESC";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, trangThai);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                HoaDon hd = new HoaDon();
                hd.setMaHoaDon(rs.getInt("maHoaDon"));
                hd.setThoiGian(rs.getTimestamp("thoiGian"));
                hd.setMaKhach(rs.getInt("maKhach"));
                hd.setTinhTrangDon(rs.getString("tinhTrangDon"));
                hd.setTenNhanVien(rs.getString("hoVaTen"));
                hd.setThanhTien(rs.getLong("thanhTien"));
                list.add(hd);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
    public void setHDHoanThanh(int mhd){
        int kt = 0;
        Connection con = JDBCConnection.getJDBCConnection();
        String sql = "UPDATE tblHoaDon" +
                     " SET tinhTrangDon = ?" +
                     " WHERE maHoaDon = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "Hoàn thành");
            ps.setInt(2, mhd);
            kt = ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println(kt);
    }
}
