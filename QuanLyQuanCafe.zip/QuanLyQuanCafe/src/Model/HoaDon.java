
package Model;

import java.sql.Timestamp;

public class HoaDon {
    private int maHoaDon;
    private Timestamp thoiGian;
    private long tongCong;
    private int chietKhau;
    private int vat;
    private long thanhTien;
    private long tienKhachTra;
    private int maKhach;
    private String tinhTrangDon;
    private int maNhanVien;
    private String tenNhanVien;

    public HoaDon() {
    }

    public int getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(int maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public Timestamp getThoiGian() {
        return thoiGian;
    }

    public void setThoiGian(Timestamp thoiGian) {
        this.thoiGian = thoiGian;
    }

    public long getTongCong() {
        return tongCong;
    }

    public void setTongCong(long tongCong) {
        this.tongCong = tongCong;
    }

    public int getChietKhau() {
        return chietKhau;
    }

    public void setChietKhau(int chietKhau) {
        this.chietKhau = chietKhau;
    }

    public int getVat() {
        return vat;
    }

    public void setVat(int vat) {
        this.vat = vat;
    }

    public long getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(long thanhTien) {
        this.thanhTien = thanhTien;
    }

    public long getTienKhachTra() {
        return tienKhachTra;
    }

    public void setTienKhachTra(long tienKhachTra) {
        this.tienKhachTra = tienKhachTra;
    }

    public int getMaKhach() {
        return maKhach;
    }

    public void setMaKhach(int maKhach) {
        this.maKhach = maKhach;
    }

    public String getTinhTrangDon() {
        return tinhTrangDon;
    }

    public void setTinhTrangDon(String tinhTrangDon) {
        this.tinhTrangDon = tinhTrangDon;
    }

    public int getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(int maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public String getTenNhanVien() {
        return tenNhanVien;
    }

    public void setTenNhanVien(String tenNhanVien) {
        this.tenNhanVien = tenNhanVien;
    }
    
}
