
package View;

import DAO.CafeDAO;
import DAO.ChiTietDonHangDAO;
import DAO.HoaDonDAO;
import DAO.NhanVienDAO;
import Model.Cafe;
import Model.ChiTietDonHang;
import Model.HoaDon;
import Model.NhanVien;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public final class BanCafeFrame extends javax.swing.JFrame implements ActionListener{
    private CafeDAO cfdao;
    private HoaDonDAO hddao;
    private ChiTietDonHangDAO ctdhdao;
    private NhanVienDAO nvdao;
    private DefaultTableModel model, model2;
    private JButton bt;
    private long tongCong, thanhTien;
    NhanVien nv2;
    public int maNhanVien;
    public String maQuyen;
    public BanCafeFrame(NhanVien nv) {
        initComponents();
        nv2 = new NhanVien();
        nv2 = nv;
        tenTK.setText("Xin chào " + nv.getHoVaTen());
        maNhanVien = nv.getMaNhanVien();
        cfdao = new CafeDAO();
        hddao = new HoaDonDAO();
        ctdhdao = new ChiTietDonHangDAO();
        nvdao = new NhanVienDAO();
        model = new DefaultTableModel()
        {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        model2 = new DefaultTableModel()
        {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        hoaDonTable.setModel(model);
        model.addColumn("Mã hóa đơn");
        model.addColumn("Thời gian");
        model.addColumn("Thành tiền");
        model.addColumn("Mã khách");
        model.addColumn("Tình trạng đơn");
        chiTietHDTB.setModel(model2);
        model2.addColumn("Tên Cafe");
        model2.addColumn("Số lượng");
        model2.addColumn("Đơn giá");
        model2.addColumn("Thành tiền");
        ListSelectionModel lsm = hoaDonTable.getSelectionModel();
        lsm.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lsm.addListSelectionListener(new ListSelectionListener(){
            @Override
            public void valueChanged(ListSelectionEvent e){
                int row = hoaDonTable.getSelectedRow();
                if(row == -1)
                    return;
                int mhd = Integer.parseInt(String.valueOf(hoaDonTable.getValueAt(row, 0)));
                HoaDon hd = hddao.getChiTiet1HD(mhd);
                maKhachTF.setText(String.valueOf(hd.getMaKhach()));
                tongCongTF.setText(String.valueOf(hd.getTongCong()));
                chietKhauTF.setText(String.valueOf(hd.getChietKhau()));
                vatTF.setText(String.valueOf(hd.getVat()));
                long tt = hd.getTongCong()*(100-hd.getChietKhau()+hd.getVat())/100;
                thanhTienTF.setText(String.valueOf(tt));
                tienKhachTraTF.setText(String.valueOf(hd.getTienKhachTra()));
                tienThuaTF.setText(String.valueOf(hd.getTienKhachTra()-tt));
                setDataCTHD(ctdhdao.getChiTietDonHang(mhd));
            }
        });
        setDataHDTrongNgay(hddao.getDSHDTrongNgay());
        thucDonPanel.setVisible(true);
        thucDonBT.setBackground(new Color(0, 102, 102));
        thucDonBT.setForeground(Color.white);
        hoaDonPanel.setVisible(false);
        hoaDonBT.setBackground(Color.white);
        hoaDonBT.setForeground(Color.black);
        setDataMonCafe(cfdao.getAllCafeKD());
    }
    
    public void setDataMonCafe(List<Cafe> lcf){
        dsThucDon.removeAll();
        sauBT.setEnabled(false);
        int trang = Integer.parseInt(trangCF.getText());
        if(trang > 1)
            truocBT.setEnabled(true);
        else
            truocBT.setEnabled(false);
        int dem = 0;
        for(Cafe cf : lcf){
            dem++;
            if(dem > (trang - 1)*21 && dem <= trang*21){
                bt = new JButton(cf.getTenCafe() + " " + cf.getGiaBan() +"đ");
                bt.setSize(60, 60);
                bt.setBackground(Color.white);
                bt.addActionListener(this);
                bt.setActionCommand(String.valueOf(cf.getMaCafe()));
                dsThucDon.add(bt);
            }
        }
        if(dem <= trang*21)
            for(int i = ++dem; i <= trang*21; i++){
                bt = new JButton();
                bt.setSize(60, 60);
                bt.setBackground(Color.white);
                dsThucDon.add(bt);
                bt.setEnabled(false);
            }
        else
            sauBT.setEnabled(true);
        dsThucDon.updateUI();
    }
    public void setDataHDTrongNgay(List<HoaDon> lhd){
        model.setRowCount(0);
        for(HoaDon hd : lhd){
            model.addRow(new Object[]{
                hd.getMaHoaDon(),
                hd.getThoiGian(),
                hd.getThanhTien(),
                hd.getMaKhach(),
                hd.getTinhTrangDon()
            });
        }
    }
    public void setDataCTHD(List<ChiTietDonHang> cthdList){
        model2.setRowCount(0);
        for(ChiTietDonHang cthd : cthdList){
            model2.addRow(new Object[]{
                cthd.getTenCafe(),
                cthd.getDonGia(),
                cthd.getSoLuong(),
                cthd.getThanhTien()
            });
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent event) {
        int mcf = Integer.parseInt(event.getActionCommand());
        int ck, v;
        Cafe cf = new Cafe();
        cf = cfdao.getCafe(mcf);
        int row = model2.getRowCount();
        int kt = 0;
        for(int i = 0; i < row; i++)
            if(String.valueOf(model2.getValueAt(i, 0)).equals(cf.getTenCafe())){
                kt = 1;
            }
        if(kt == 0){
            model2.addRow(new Object[]{
                    cf.getTenCafe(),
                    1,
                    cf.getGiaBan(),
                    cf.getGiaBan()
                });
        }
        setThanhTienChiTiet();
        setTongCong();
        setThanhTien();
    }
    public void setTongCong(){
        tongCong = 0;
        for(int i = 0; i < model2.getRowCount(); i++){
            tongCong += Integer.parseInt(String.valueOf(chiTietHDTB.getValueAt(i, 3)));
        }
        tongCongTF.setText(String.valueOf(tongCong));
    }
    
    public void setThanhTienChiTiet(){
        int row = model2.getRowCount();
        for(int i = 0; i < row; i++){
            int sl = (int) model2.getValueAt(i, 1);
            long dg = (long) model2.getValueAt(i, 2);
            model2.setValueAt(sl*dg, i, 3);
        }
    }
    public void setThanhTien(){
        int ck, v;
        try {
            ck = Integer.parseInt(chietKhauTF.getText());
        } catch (Exception e1) {
            ck = 0;
            System.out.println(e1);
        }
        
        try {
            v = Integer.parseInt(vatTF.getText());
        } catch (Exception e2) {
            v = 0;
            System.out.println(e2);
        }
        thanhTien = tongCong*(100-ck+v)/100;
        thanhTienTF.setText(String.valueOf(thanhTien));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainLP = new javax.swing.JLayeredPane();
        hoaDonPanel = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        trangThaiCBB = new javax.swing.JComboBox<>();
        hoanThanhBT = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        hoaDonTable = new javax.swing.JTable();
        thucDonPanel = new javax.swing.JPanel();
        danhMuc = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        tatCaBT = new javax.swing.JButton();
        cafeDXBT = new javax.swing.JButton();
        thachBT = new javax.swing.JButton();
        smoothiesBT = new javax.swing.JButton();
        socolaBT = new javax.swing.JButton();
        espressoBT = new javax.swing.JButton();
        traiCayBT = new javax.swing.JButton();
        dsThucDon = new javax.swing.JPanel();
        truocBT = new javax.swing.JButton();
        sauBT = new javax.swing.JButton();
        trangCF = new javax.swing.JLabel();
        hoaDonThanhToan = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        chiTietHDTB = new javax.swing.JTable();
        in = new javax.swing.JButton();
        baoCheBien = new javax.swing.JButton();
        thanhToanBT = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        tienKhachTraTF = new javax.swing.JTextField();
        tienThuaTF = new javax.swing.JTextField();
        vatTF = new javax.swing.JTextField();
        chietKhauTF = new javax.swing.JTextField();
        truBT = new javax.swing.JButton();
        congBT = new javax.swing.JButton();
        xoaBT = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        maKhachTF = new javax.swing.JTextField();
        tongCongTF = new javax.swing.JLabel();
        thanhTienTF = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        thucDonBT = new javax.swing.JButton();
        hoaDonBT = new javax.swing.JButton();
        nhapTimKiem = new javax.swing.JTextField();
        timKiem = new javax.swing.JButton();
        hoaDom = new javax.swing.JLabel();
        dangXuatBT = new javax.swing.JButton();
        tenTK = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bán Cafe");

        mainLP.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Hóa đơn trong ngày");

        jLabel10.setText("Trang thái:");

        trangThaiCBB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tất cả", "Đang xử lý", "Hoàn thành" }));
        trangThaiCBB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trangThaiCBBActionPerformed(evt);
            }
        });

        hoanThanhBT.setBackground(new java.awt.Color(255, 255, 255));
        hoanThanhBT.setText("Hoàn thành");
        hoanThanhBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hoanThanhBTActionPerformed(evt);
            }
        });

        hoaDonTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        hoaDonTable.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane2.setViewportView(hoaDonTable);

        javax.swing.GroupLayout hoaDonPanelLayout = new javax.swing.GroupLayout(hoaDonPanel);
        hoaDonPanel.setLayout(hoaDonPanelLayout);
        hoaDonPanelLayout.setHorizontalGroup(
            hoaDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hoaDonPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(hoaDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 730, Short.MAX_VALUE)
                    .addGroup(hoaDonPanelLayout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(350, 350, 350)
                        .addComponent(hoanThanhBT)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(trangThaiCBB, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 24, Short.MAX_VALUE)))
                .addContainerGap())
        );
        hoaDonPanelLayout.setVerticalGroup(
            hoaDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, hoaDonPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(hoaDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(trangThaiCBB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hoanThanhBT))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 556, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel2.setForeground(new java.awt.Color(0, 102, 102));
        jLabel2.setText("Danh mục:");

        tatCaBT.setBackground(new java.awt.Color(0, 153, 153));
        tatCaBT.setForeground(new java.awt.Color(255, 255, 255));
        tatCaBT.setText("Tất cả");
        tatCaBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tatCaBTActionPerformed(evt);
            }
        });

        cafeDXBT.setBackground(new java.awt.Color(0, 153, 153));
        cafeDXBT.setForeground(new java.awt.Color(255, 255, 255));
        cafeDXBT.setText("Cafe đá xay");
        cafeDXBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cafeDXBTActionPerformed(evt);
            }
        });

        thachBT.setBackground(new java.awt.Color(0, 153, 153));
        thachBT.setForeground(new java.awt.Color(255, 255, 255));
        thachBT.setText("Thạch và topping");
        thachBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thachBTActionPerformed(evt);
            }
        });

        smoothiesBT.setBackground(new java.awt.Color(0, 153, 153));
        smoothiesBT.setForeground(new java.awt.Color(255, 255, 255));
        smoothiesBT.setText("Smoothies");
        smoothiesBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smoothiesBTActionPerformed(evt);
            }
        });

        socolaBT.setBackground(new java.awt.Color(0, 153, 153));
        socolaBT.setForeground(new java.awt.Color(255, 255, 255));
        socolaBT.setText("Socola");
        socolaBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                socolaBTActionPerformed(evt);
            }
        });

        espressoBT.setBackground(new java.awt.Color(0, 153, 153));
        espressoBT.setForeground(new java.awt.Color(255, 255, 255));
        espressoBT.setText("Cafe Espresso");
        espressoBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                espressoBTActionPerformed(evt);
            }
        });

        traiCayBT.setBackground(new java.awt.Color(0, 153, 153));
        traiCayBT.setForeground(new java.awt.Color(255, 255, 255));
        traiCayBT.setText("Trái cây đá xay");
        traiCayBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                traiCayBTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout danhMucLayout = new javax.swing.GroupLayout(danhMuc);
        danhMuc.setLayout(danhMucLayout);
        danhMucLayout.setHorizontalGroup(
            danhMucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(danhMucLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tatCaBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(socolaBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cafeDXBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thachBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(smoothiesBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(espressoBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(traiCayBT)
                .addContainerGap(44, Short.MAX_VALUE))
        );
        danhMucLayout.setVerticalGroup(
            danhMucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, danhMucLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(danhMucLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tatCaBT)
                    .addComponent(jLabel2)
                    .addComponent(cafeDXBT)
                    .addComponent(thachBT)
                    .addComponent(smoothiesBT)
                    .addComponent(socolaBT)
                    .addComponent(espressoBT)
                    .addComponent(traiCayBT))
                .addContainerGap())
        );

        dsThucDon.setLayout(new java.awt.GridLayout(7, 0, 15, 15));

        truocBT.setText("<");
        truocBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                truocBTActionPerformed(evt);
            }
        });

        sauBT.setText(">");
        sauBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sauBTActionPerformed(evt);
            }
        });

        trangCF.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        trangCF.setText("1");

        javax.swing.GroupLayout thucDonPanelLayout = new javax.swing.GroupLayout(thucDonPanel);
        thucDonPanel.setLayout(thucDonPanelLayout);
        thucDonPanelLayout.setHorizontalGroup(
            thucDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(thucDonPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(thucDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(danhMuc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dsThucDon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(thucDonPanelLayout.createSequentialGroup()
                .addGap(341, 341, 341)
                .addComponent(truocBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(trangCF, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sauBT)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        thucDonPanelLayout.setVerticalGroup(
            thucDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(thucDonPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(danhMuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dsThucDon, javax.swing.GroupLayout.PREFERRED_SIZE, 502, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(thucDonPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(truocBT)
                    .addComponent(sauBT)
                    .addComponent(trangCF)))
        );

        mainLP.setLayer(hoaDonPanel, javax.swing.JLayeredPane.DEFAULT_LAYER);
        mainLP.setLayer(thucDonPanel, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout mainLPLayout = new javax.swing.GroupLayout(mainLP);
        mainLP.setLayout(mainLPLayout);
        mainLPLayout.setHorizontalGroup(
            mainLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainLPLayout.createSequentialGroup()
                .addComponent(thucDonPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(mainLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(hoaDonPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        mainLPLayout.setVerticalGroup(
            mainLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainLPLayout.createSequentialGroup()
                .addComponent(thucDonPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(10, 10, 10))
            .addGroup(mainLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(hoaDonPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        hoaDonThanhToan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        chiTietHDTB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tên Cafe", "Số lượng", "Đơn giá", "Thành tiền"
            }
        ));
        jScrollPane1.setViewportView(chiTietHDTB);

        in.setBackground(new java.awt.Color(102, 102, 102));
        in.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        in.setForeground(new java.awt.Color(255, 255, 255));
        in.setText("In");
        in.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inActionPerformed(evt);
            }
        });

        baoCheBien.setBackground(new java.awt.Color(51, 204, 0));
        baoCheBien.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        baoCheBien.setForeground(new java.awt.Color(255, 255, 255));
        baoCheBien.setText("Báo chế biến");
        baoCheBien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baoCheBienActionPerformed(evt);
            }
        });

        thanhToanBT.setBackground(new java.awt.Color(0, 153, 153));
        thanhToanBT.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        thanhToanBT.setForeground(new java.awt.Color(255, 255, 255));
        thanhToanBT.setText("Thanh toán");
        thanhToanBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thanhToanBTActionPerformed(evt);
            }
        });

        jLabel3.setText("Chiết khấu:");

        jLabel4.setText("VAT:");

        jLabel5.setText("Tổng cộng:");

        jLabel6.setText("Tiền khách trả:");

        jLabel7.setText("Tiền thừa");

        jLabel8.setText("Thành tiền:");

        tienKhachTraTF.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        tienKhachTraTF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tienKhachTraTFKeyPressed(evt);
            }
        });

        tienThuaTF.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        vatTF.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        vatTF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                vatTFKeyPressed(evt);
            }
        });

        chietKhauTF.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        chietKhauTF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                chietKhauTFKeyPressed(evt);
            }
        });

        truBT.setBackground(new java.awt.Color(0, 153, 153));
        truBT.setForeground(new java.awt.Color(255, 255, 255));
        truBT.setText("-");
        truBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                truBTActionPerformed(evt);
            }
        });

        congBT.setBackground(new java.awt.Color(0, 153, 153));
        congBT.setForeground(new java.awt.Color(255, 255, 255));
        congBT.setText("+");
        congBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                congBTActionPerformed(evt);
            }
        });

        xoaBT.setBackground(new java.awt.Color(0, 153, 153));
        xoaBT.setForeground(new java.awt.Color(255, 255, 255));
        xoaBT.setText("Xóa");
        xoaBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                xoaBTActionPerformed(evt);
            }
        });

        jLabel1.setText("Mã khách:");

        maKhachTF.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        tongCongTF.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tongCongTF.setText("0");

        thanhTienTF.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        thanhTienTF.setText("0");

        javax.swing.GroupLayout hoaDonThanhToanLayout = new javax.swing.GroupLayout(hoaDonThanhToan);
        hoaDonThanhToan.setLayout(hoaDonThanhToanLayout);
        hoaDonThanhToanLayout.setHorizontalGroup(
            hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hoaDonThanhToanLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(hoaDonThanhToanLayout.createSequentialGroup()
                        .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7)
                            .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4)
                                .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tienKhachTraTF)
                            .addComponent(tienThuaTF)
                            .addComponent(vatTF)
                            .addComponent(chietKhauTF)
                            .addComponent(tongCongTF, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(thanhTienTF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, hoaDonThanhToanLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(truBT, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(congBT, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(xoaBT, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(hoaDonThanhToanLayout.createSequentialGroup()
                        .addComponent(in, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(baoCheBien, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(thanhToanBT, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(hoaDonThanhToanLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(33, 33, 33)
                        .addComponent(maKhachTF)))
                .addContainerGap())
        );
        hoaDonThanhToanLayout.setVerticalGroup(
            hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hoaDonThanhToanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(congBT)
                    .addComponent(truBT)
                    .addComponent(xoaBT))
                .addGap(15, 15, 15)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(maKhachTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tongCongTF))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(chietKhauTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(vatTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(thanhTienTF))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tienKhachTraTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tienThuaTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(hoaDonThanhToanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(in, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(baoCheBien, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(thanhToanBT, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(65, Short.MAX_VALUE))
        );

        menu.setBackground(new java.awt.Color(102, 153, 255));

        thucDonBT.setBackground(new java.awt.Color(255, 255, 255));
        thucDonBT.setText("Thực đơn");
        thucDonBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thucDonBTActionPerformed(evt);
            }
        });

        hoaDonBT.setBackground(new java.awt.Color(255, 255, 255));
        hoaDonBT.setText("Hóa đơn trong ngày");
        hoaDonBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hoaDonBTActionPerformed(evt);
            }
        });

        nhapTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nhapTimKiemActionPerformed(evt);
            }
        });

        timKiem.setBackground(new java.awt.Color(255, 255, 255));
        timKiem.setText("Tìm kiếm");
        timKiem.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        timKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timKiemActionPerformed(evt);
            }
        });

        hoaDom.setBackground(new java.awt.Color(255, 255, 255));
        hoaDom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        hoaDom.setText("Hóa đơn");

        dangXuatBT.setBackground(new java.awt.Color(255, 255, 255));
        dangXuatBT.setText("Đăng xuất");
        dangXuatBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dangXuatBTActionPerformed(evt);
            }
        });

        tenTK.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        tenTK.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tenTK.setText("Họ và tên");

        javax.swing.GroupLayout menuLayout = new javax.swing.GroupLayout(menu);
        menu.setLayout(menuLayout);
        menuLayout.setHorizontalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(thucDonBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hoaDonBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(nhapTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timKiem)
                .addGap(18, 18, 18)
                .addComponent(hoaDom, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87)
                .addComponent(tenTK, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dangXuatBT)
                .addContainerGap())
        );
        menuLayout.setVerticalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(menuLayout.createSequentialGroup()
                        .addGroup(menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(hoaDonBT)
                            .addComponent(nhapTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(timKiem)
                            .addComponent(dangXuatBT)
                            .addComponent(thucDonBT)
                            .addComponent(hoaDom, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(tenTK, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(hoaDonThanhToan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(menu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(hoaDonThanhToan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mainLP))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void hoaDonBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hoaDonBTActionPerformed
        hoaDonPanel.setVisible(true);
        hoaDonBT.setBackground(new Color(0, 102, 102));
        hoaDonBT.setForeground(Color.white);
        thucDonPanel.setVisible(false);
        thucDonBT.setBackground(Color.white);
        thucDonBT.setForeground(Color.black);
        hoaDonThanhToan.setEnabled(false);
        truBT.setEnabled(false);
        congBT.setEnabled(false);
        xoaBT.setEnabled(false);
        thanhToanBT.setEnabled(false);
        in.setEnabled(false);
        baoCheBien.setEnabled(false);
        setDataHDTrongNgay(hddao.getDSHDTrongNgay());
    }//GEN-LAST:event_hoaDonBTActionPerformed

    private void thucDonBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thucDonBTActionPerformed
        hoaDonPanel.setVisible(false);
        hoaDonBT.setBackground(Color.white);
        hoaDonBT.setForeground(Color.black);
        thucDonPanel.setVisible(true);
        thucDonBT.setBackground(new Color(0, 102, 102));
        thucDonBT.setForeground(Color.white);
        model2.setRowCount(0);
        truBT.setEnabled(true);
        congBT.setEnabled(true);
        xoaBT.setEnabled(true);
        thanhToanBT.setEnabled(true);
        in.setEnabled(true);
        baoCheBien.setEnabled(true);
        maKhachTF.setText("");
        tongCongTF.setText("");
        chietKhauTF.setText("");
        vatTF.setText("");
        thanhTienTF.setText("");
        tienKhachTraTF.setText("");
        tienThuaTF.setText("");
    }//GEN-LAST:event_thucDonBTActionPerformed

    private void thanhToanBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thanhToanBTActionPerformed
        if(tienKhachTraTF.getText().equals("") || maKhachTF.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Bạn chưa nhập đầy đủ!");
        }
        else{
            try {
                HoaDon hd = new HoaDon();
                if(chietKhauTF.getText().equals(""))
                    hd.setChietKhau(0);
                else
                    hd.setChietKhau(Integer.parseInt(chietKhauTF.getText()));
                if(vatTF.getText().equals(""))
                    hd.setVat(0);
                else
                    hd.setVat(Integer.parseInt(vatTF.getText()));
                hd.setTienKhachTra(Long.parseLong(tienKhachTraTF.getText()));
                hd.setMaKhach(Integer.parseInt(maKhachTF.getText()));
                hd.setMaNhanVien(maNhanVien);
                hddao.addHoaDon(hd);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        ChiTietDonHang ctdh;
        if(model2.getRowCount() == 0)
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn món!");
        else
        {
            for(int i = 0; i < model2.getRowCount(); i++){
                try {
                    ctdh = new ChiTietDonHang();
                    ctdh.setMaHoaDon(hddao.getMaHDMoiThem());
                    Cafe cf = new Cafe();
                    cf = cfdao.getCafeTen((String) chiTietHDTB.getValueAt(i, 0));
                    ctdh.setMaCafe(cf.getMaCafe());
                    ctdh.setSoLuong(Integer.parseInt(String.valueOf(chiTietHDTB.getValueAt(i, 1))));
                    ctdh.setDonGia(Long.parseLong(String.valueOf(chiTietHDTB.getValueAt(i, 2))));
                    ctdhdao.addCTDH(ctdh);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if(hddao.kt == 1 && ctdhdao.kt == 1){
                JOptionPane.showMessageDialog(this, "Thanh toán thành công");
                new BanCafeFrame(nv2).setVisible(true);
                this.dispose();
            }
            else
                JOptionPane.showMessageDialog(this, "Thanh toán thất bại!");
        }
    }//GEN-LAST:event_thanhToanBTActionPerformed

    private void chietKhauTFKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_chietKhauTFKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            setThanhTien();
        }
    }//GEN-LAST:event_chietKhauTFKeyPressed

    private void vatTFKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_vatTFKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            setThanhTien();
        }
    }//GEN-LAST:event_vatTFKeyPressed

    private void tienKhachTraTFKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tienKhachTraTFKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            long tienThua, tKhachTra;
            try {
                tKhachTra = Integer.parseInt(tienKhachTraTF.getText());
            } catch (Exception e) {
                tKhachTra = 0;
                System.out.println(e);
            }
            if(tKhachTra < thanhTien)
                JOptionPane.showMessageDialog(this, "Tiền khách trả phải lớn hơn hặc bằng thành tiền!");
            else{
                tienThua = tKhachTra - thanhTien;
                tienThuaTF.setText(String.valueOf(tienThua));
            }
        }
    }//GEN-LAST:event_tienKhachTraTFKeyPressed

    private void sauBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sauBTActionPerformed
        int trang = Integer.parseInt(trangCF.getText()) + 1;
        trangCF.setText(String.valueOf(trang));
        setDataMonCafe(cfdao.getAllCafeKD());
    }//GEN-LAST:event_sauBTActionPerformed

    private void truocBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_truocBTActionPerformed
        int trang = Integer.parseInt(trangCF.getText()) - 1;
        trangCF.setText(String.valueOf(trang));
        setDataMonCafe(cfdao.getAllCafeKD());
    }//GEN-LAST:event_truocBTActionPerformed

    private void tatCaBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tatCaBTActionPerformed
        trangCF.setText("1");
        setDataMonCafe(cfdao.getAllCafeKD());
    }//GEN-LAST:event_tatCaBTActionPerformed

    private void socolaBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_socolaBTActionPerformed
        // Socola
        trangCF.setText("1");
        setDataMonCafe(cfdao.getNhomCafeKD("Socola"));
    }//GEN-LAST:event_socolaBTActionPerformed

    private void cafeDXBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cafeDXBTActionPerformed
        // Cafe đá xay
        trangCF.setText("1");
        setDataMonCafe(cfdao.getNhomCafeKD("Cafe đá xay"));
    }//GEN-LAST:event_cafeDXBTActionPerformed

    private void thachBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thachBTActionPerformed
        // Thạch và topping
        trangCF.setText("1");
        setDataMonCafe(cfdao.getNhomCafeKD("Thạch và topping"));
    }//GEN-LAST:event_thachBTActionPerformed

    private void smoothiesBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smoothiesBTActionPerformed
        // Smoothies
        trangCF.setText("1");
        setDataMonCafe(cfdao.getNhomCafeKD("Smoothies"));
    }//GEN-LAST:event_smoothiesBTActionPerformed

    private void espressoBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_espressoBTActionPerformed
        // Cafe Espresso
        trangCF.setText("1");
        setDataMonCafe(cfdao.getNhomCafeKD("Cafe Espresso"));
    }//GEN-LAST:event_espressoBTActionPerformed

    private void traiCayBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_traiCayBTActionPerformed
        // Trái cây đá xay
        trangCF.setText("1");
        setDataMonCafe(cfdao.getNhomCafeKD("Trái cây đá xay"));
    }//GEN-LAST:event_traiCayBTActionPerformed

    private void trangThaiCBBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trangThaiCBBActionPerformed
        try {
            int lc = trangThaiCBB.getSelectedIndex();
            if(lc == -1)
                return;
            else
                if(lc == 0)
                    setDataHDTrongNgay(hddao.getDSHDTrongNgay());
                else
                    if(lc == 1)
                        setDataHDTrongNgay(hddao.getDSHDTrongNgayTT("Đang xử lý"));
                    else
                        setDataHDTrongNgay(hddao.getDSHDTrongNgayTT("Hoàn thành"));
        } catch (Exception e) {
        }
    }//GEN-LAST:event_trangThaiCBBActionPerformed

    private void congBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_congBTActionPerformed
        int row = chiTietHDTB.getSelectedRow();
        if(row != -1){
            int sl =  (int) chiTietHDTB.getValueAt(row, 1);
            chiTietHDTB.setValueAt(sl + 1, row, 1);
            setThanhTienChiTiet();
            setTongCong();
            setThanhTien();
        }
        else
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn Cafe!");
    }//GEN-LAST:event_congBTActionPerformed

    private void truBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_truBTActionPerformed
        int row = chiTietHDTB.getSelectedRow();
        if(row != -1){
            int sl =  (int) chiTietHDTB.getValueAt(row, 1);
            if(sl > 1){
                chiTietHDTB.setValueAt(sl - 1, row, 1);
                setThanhTienChiTiet();
                setTongCong();
                setThanhTien();
            } 
            else
                JOptionPane.showMessageDialog(this, "Số lượng đang là 1!");
        }
        else
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn Cafe!");
    }//GEN-LAST:event_truBTActionPerformed

    private void xoaBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_xoaBTActionPerformed
        int row = chiTietHDTB.getSelectedRow();
        if(row != -1)
            while(row != -1){
                model2.removeRow(row);
                row = chiTietHDTB.getSelectedRow();
                setThanhTienChiTiet();
                setTongCong();
                setThanhTien();
            }
        else
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn Cafe cần xóa!");
    }//GEN-LAST:event_xoaBTActionPerformed

    private void hoanThanhBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hoanThanhBTActionPerformed
        int row = hoaDonTable.getSelectedRow();
        if(row != -1){
            int confirm = JOptionPane.showConfirmDialog(this, "Chắc chắn đã hoàn thành!");
            if(confirm == JOptionPane.YES_OPTION){
                int mhd = (int) hoaDonTable.getValueAt(row, 0);
                hddao.setHDHoanThanh(mhd);
                setDataHDTrongNgay(hddao.getDSHDTrongNgay());
            }
        }
        else
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn hóa đơn!");
    }//GEN-LAST:event_hoanThanhBTActionPerformed

    private void baoCheBienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baoCheBienActionPerformed
        JOptionPane.showMessageDialog(this, "Đã báo chế biến!");
    }//GEN-LAST:event_baoCheBienActionPerformed

    private void inActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inActionPerformed
        JOptionPane.showMessageDialog(this, "Đã in!");
    }//GEN-LAST:event_inActionPerformed

    private void dangXuatBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dangXuatBTActionPerformed
        DangNhapFrame dn = new DangNhapFrame();
        dn.setVisible(true);
        dn.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_dangXuatBTActionPerformed

    private void nhapTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nhapTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nhapTimKiemActionPerformed

    private void timKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timKiemActionPerformed
        List<Cafe> list = new ArrayList<>();
        Cafe cf = new Cafe();
        cf = cfdao.getCafeTen(nhapTimKiem.getText());
        list.add(cf);
        if(list.get(0).getTenCafe() == null)
            JOptionPane.showMessageDialog(this, "Không có kết quả nào!");
        else
            setDataMonCafe(list);
    }//GEN-LAST:event_timKiemActionPerformed

//    public static void main(String args[]) {
//
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                BanCafeFrame bc = new BanCafeFrame();
//                bc.setVisible(true);
//                bc.setLocationRelativeTo(null);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton baoCheBien;
    private javax.swing.JButton cafeDXBT;
    private javax.swing.JTable chiTietHDTB;
    private javax.swing.JTextField chietKhauTF;
    private javax.swing.JButton congBT;
    private javax.swing.JButton dangXuatBT;
    private javax.swing.JPanel danhMuc;
    private javax.swing.JPanel dsThucDon;
    private javax.swing.JButton espressoBT;
    private javax.swing.JLabel hoaDom;
    private javax.swing.JButton hoaDonBT;
    private javax.swing.JPanel hoaDonPanel;
    private javax.swing.JTable hoaDonTable;
    private javax.swing.JPanel hoaDonThanhToan;
    private javax.swing.JButton hoanThanhBT;
    private javax.swing.JButton in;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField maKhachTF;
    private javax.swing.JLayeredPane mainLP;
    private javax.swing.JPanel menu;
    private javax.swing.JTextField nhapTimKiem;
    private javax.swing.JButton sauBT;
    private javax.swing.JButton smoothiesBT;
    private javax.swing.JButton socolaBT;
    private javax.swing.JButton tatCaBT;
    private javax.swing.JLabel tenTK;
    private javax.swing.JButton thachBT;
    private javax.swing.JLabel thanhTienTF;
    private javax.swing.JButton thanhToanBT;
    private javax.swing.JButton thucDonBT;
    private javax.swing.JPanel thucDonPanel;
    private javax.swing.JTextField tienKhachTraTF;
    private javax.swing.JTextField tienThuaTF;
    private javax.swing.JButton timKiem;
    private javax.swing.JLabel tongCongTF;
    private javax.swing.JButton traiCayBT;
    private javax.swing.JLabel trangCF;
    private javax.swing.JComboBox<String> trangThaiCBB;
    private javax.swing.JButton truBT;
    private javax.swing.JButton truocBT;
    private javax.swing.JTextField vatTF;
    private javax.swing.JButton xoaBT;
    // End of variables declaration//GEN-END:variables
}
